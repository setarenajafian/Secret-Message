﻿namespace SecretLanguageDecoder;

public class SecretLangDecoder2 : ICoder
{
    //Constructor Injection
    private readonly DecoderService encoderService;
    public SecretLangDecoder2(DecoderService encoderService)
    {
        this.encoderService = encoderService;
    }
    //method2 :
    public string Decode(string encodedMessage, string senderName, string receiverName)
    {
        int senderSum = encoderService.GetNameSum(senderName);
        int receiverSum = encoderService.GetNameSum(receiverName);

        int offset = (int)((double)(senderSum * receiverSum) / (senderSum + receiverSum)) % 52;

        char[] decodedMessage = new char[encodedMessage.Length];

        for (int i = 0; i < encodedMessage.Length; i++)
        {
            decodedMessage[i] = encoderService.GetDecodedChar(encodedMessage[i], offset);
        }

        return new string(decodedMessage);
    }
}
