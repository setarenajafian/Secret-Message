﻿using SecretLanguageDecoder;

namespace SecretLanguageDecoder;

public class SecretLanguageEncoder : ICoder
{
    private readonly EncoderService encoderService;

    public SecretLanguageEncoder(EncoderService encoderService)
    {
        this.encoderService = encoderService;
    }

    public string Decode(string encodedMessage, string senderName, string receiverName)
    {
        int senderSum = encoderService.GetNameSum(senderName);
        int receiverSum = encoderService.GetNameSum(receiverName);
        int offset = (senderSum + receiverSum) % 52;

        char[] decodedMessage = new char[encodedMessage.Length];
        for (int i = 0; i < encodedMessage.Length; i++)
        {
            decodedMessage[i] = encoderService.GetDecodedChar(encodedMessage[i], offset);
        }

        return new string(decodedMessage);
    }
}
