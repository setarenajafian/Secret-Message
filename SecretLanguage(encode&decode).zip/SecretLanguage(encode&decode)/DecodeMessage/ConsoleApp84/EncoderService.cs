﻿using System;

namespace SecretLanguageDecoder;

public class EncoderService
{
    private readonly char[] symbol = new char[52]
    {
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
    };

    public int GetNameSum(string name)
    {
        int sum = 0;
        foreach (char ch in name)
        {
            int index = Array.IndexOf(symbol, ch);
            if (index >= 0) sum += index + 1; // Index starts at 0, add 1
        }
        return sum;
    }

    public char GetDecodedChar(char ch, int offset)
    {
        int index = Array.IndexOf(symbol, ch);
        if (index >= 0)
        {
            int newIndex = (index - offset + 52) % 52; // Add 52 to handle negatives
            return symbol[newIndex];
        }
        return ch; // Return non-alphabet characters unchanged
    }
}
