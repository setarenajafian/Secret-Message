﻿using System;

namespace SecretLanguageDecoder;

public class DecoderService
{
    public readonly char[] Symbols =
    {
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
    };

    public int GetNameSum(string name)
    {
        int sum = 0;
        foreach (char x in name)
        {
            int index = Array.IndexOf(Symbols, x);
            if (index >= 0) sum += index + 1; 
        }
        return sum;
    }

    public char GetDecodedChar(char x, int offset)
    {
        int index = Array.IndexOf(Symbols, x);

        if (index >= 0)
        {
            int newIndex = (index - offset + 52) % 52; 
            return Symbols[newIndex];
        }
        return x; 
    }
}
