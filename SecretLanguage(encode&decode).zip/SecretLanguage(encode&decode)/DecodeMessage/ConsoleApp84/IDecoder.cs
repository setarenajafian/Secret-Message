﻿namespace SecretLanguageDecoder
{
    public interface ICoder
    {
        string Decode(string encodedMessage, string senderName, string receiverName);
    }
}
