﻿using System;
using System.IO;
using Figgle;

namespace SecretLanguageDecoder;
class Program
{
    static void Main()
    {
        // provides the methods to compute name sums and decode characters
        DecoderService decoderService = new DecoderService();


        ICoder decoder = new SecretLangDecoder1(new DecoderService());
        // put this instead if you want to decode method 2 :
        //IDecoder decoder = new SecretLangDecoder2(decoderService);


        Console.Write("Enter the sender's name:");
        string senderName = Console.ReadLine();

        Console.Write("\nEnter the receiver's name:");
        string receiverName = Console.ReadLine();

        Console.Write("\nEnter your file path:");
        string encodedFilePath = Console.ReadLine();


        if (!File.Exists(encodedFilePath))
        {
            Console.WriteLine("Error! File not found. Please check the path and try again.");
            return;
        }
        try
        {
            // Loads the encoded message from the file into memory so it can be decoded
            string encodedMessage = File.ReadAllText(encodedFilePath);

            // Decode the message
            string decodedMessage = decoder.Decode(encodedMessage, senderName, receiverName);

            // Display the Decoded Message
            Console.WriteLine(FiggleFonts.Standard.Render($"\nyour Message:"));
            Console.WriteLine(decodedMessage);
           
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error while decoding: {ex.Message}");
        }
    }
}
