﻿namespace SecretLanguageDecoder;

public class SecretLangDecoder1 : ICoder
{
    //constructor Injection
    private readonly DecoderService encoderService;
    public SecretLangDecoder1(DecoderService encoderService)
    {
        this.encoderService = encoderService;
    }
    //method1 :
    public string Decode(string encodedMessage, string senderName, string receiverName)
    {
        int senderSum = encoderService.GetNameSum(senderName);
        int receiverSum = encoderService.GetNameSum(receiverName);

        int offset = (senderSum + receiverSum) % 52;

        char[] decodedMessage = new char[encodedMessage.Length];

        for (int i = 0; i < encodedMessage.Length; i++)
        {
            decodedMessage[i] = encoderService.GetDecodedChar(encodedMessage[i], offset);
        }

        return new string(decodedMessage);
    }
}
