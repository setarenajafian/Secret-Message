﻿
namespace SecretLanguage;
public interface ICoder
{
    string Encode(string message, string senderName, string receiverName);
   
}
