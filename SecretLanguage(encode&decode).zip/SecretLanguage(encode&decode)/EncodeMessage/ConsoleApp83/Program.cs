﻿using SecretLanguage;
using SecretLanguageEncode;
using System;
using System.IO;

namespace SecretLanguage;

class Program
{
    static void Main()
    {
        // provides the methods to compute name sums and encode characters
        EncoderService encoderService = new EncoderService();


        ICoder encoder = new SecretLangEncoder1(encoderService);
        //put this instead if you want to change the method :
        //ICoder encoder = new SecretLangEncoder2(encoderService);


        Console.Write("Enter the sender's name: ");
        string senderName = Console.ReadLine();

        Console.Write("\nEnter the receiver's name: ");
        string receiverName = Console.ReadLine();

        Console.Write("\nEnter your message: ");
        string message = Console.ReadLine();

        
        string encodedMessage = encoder.Encode(message, senderName, receiverName);

        string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "message.txt");
        File.WriteAllText(filePath, encodedMessage);

        string pathfile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "message.ini");
        File.WriteAllText(pathfile, encodedMessage);


        Console.WriteLine($"\nyour message is saved in :\n{filePath}\nand\n{pathfile}");
    }
}
