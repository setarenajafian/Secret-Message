﻿using SecretLanguage;

namespace SecretLanguageEncode;
public class SecretLangEncoder1 : ICoder
{
    //constructor Injection
    private readonly EncoderService encoderService;
    public SecretLangEncoder1(EncoderService encoderService)
    {
        this.encoderService = encoderService;
    }

    //method1 :
    public string Encode(string originalMessage, string senderName, string receiverName)
    {
        int senderSum = encoderService.GetNameSum(senderName);
        int receiverSum = encoderService.GetNameSum(receiverName);

        int offset = (senderSum + receiverSum) % 52;


        char[] encodedMessage = new char[originalMessage.Length];

        for (int i = 0; i < originalMessage.Length; i++)
        {
            encodedMessage[i] = encoderService.GetEncodedChar(originalMessage[i], offset);
        }
        return new string(encodedMessage);
    }
}
