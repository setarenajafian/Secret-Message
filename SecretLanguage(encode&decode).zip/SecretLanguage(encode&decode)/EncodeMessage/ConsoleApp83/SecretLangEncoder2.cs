﻿using SecretLanguage;
using SecretLanguageEncode;

namespace SecretLanguageEncode;
public class SecretLangEncoder2 : ICoder
{
    //Constructor Injection
    private readonly EncoderService encoderService;
    public SecretLangEncoder2(EncoderService encoderService)
    {
        this.encoderService = encoderService;
    }
    //method2 :
    public string Encode(string originalMessage, string senderName, string receiverName)
    {
        int senderSum = encoderService.GetNameSum(senderName);
        int receiverSum = encoderService.GetNameSum(receiverName);

        int offset = (int)((double)(senderSum * receiverSum) / (senderSum + receiverSum)) % 52;


        char[] encodedMessage = new char[originalMessage.Length];

        for (int i = 0; i < originalMessage.Length; i++)
        {
            char currentChar = originalMessage[i];
            int index = Array.IndexOf(encoderService.Symbols, currentChar);

            if (index >= 0)
            {
                int newIndex = (index + offset) % 52;
                encodedMessage[i] = encoderService.Symbols[newIndex];
            }
            else
            {
                encodedMessage[i] = currentChar;
            }
        }
        return new string(encodedMessage);
    }
}
